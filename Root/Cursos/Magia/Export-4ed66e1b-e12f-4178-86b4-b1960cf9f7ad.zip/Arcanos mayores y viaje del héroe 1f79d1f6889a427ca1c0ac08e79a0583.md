# Arcanos mayores y viaje del héroe

Created: January 4, 2022 11:00 AM
Minded: Yes
Professors: Kelly Towers
Tag: magia, tarot

Los Arcanos Mayores del Tarot son una guía que nos indica en que estado de nuestra evolución espiritual nos encontramos. Por eso algunos se asocian a una esfera especifica del arbol de la Kabbalah, y a una letra del alfabeto Hebreo. Letras de las cuales se formó la creación.

![Untitled](Arcanos%20mayores%20y%20viaje%20del%20he%CC%81roe%201f79d1f6889a427ca1c0ac08e79a0583/Untitled.png)